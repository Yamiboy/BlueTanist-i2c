/*
 * peripheral_setup.h
 *
 *  Created on: Mar 17, 2020
 *      Author: y_ami
 */

#ifndef CONFIG_PERIPHERAL_SETUP_H_
#define CONFIG_PERIPHERAL_SETUP_H_

#define EEPROM_24FC256_I2C_ADDRESS    ( 0x27 )

/**
 * I2C 1 configuration
 */
#define EEPROM_24FC256_SCL_PORT       ( HW_GPIO_PORT_0 )
#define EEPROM_24FC256_SCL_PIN        ( HW_GPIO_PIN_30 )

#define EEPROM_24FC256_SDA_PORT       ( HW_GPIO_PORT_0 )
#define EEPROM_24FC256_SDA_PIN        ( HW_GPIO_PIN_31 )

#endif /* CONFIG_PERIPHERAL_SETUP_H_ */
